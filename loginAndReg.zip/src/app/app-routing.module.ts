import { AdminComponent } from './admin/admin.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { SettingsProfileComponent } from './settings-profile/settings-profile.component';
import { SettingsComponent } from './settings/settings.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'about',component:AboutUsComponent},
  {path:'register',component:RegisterComponent},
  {path:'admin', component:AdminComponent},
  {path:'contactUs',component:ContactUsComponent},
  {path:'signin',component:LoginComponent},
  {path:'', redirectTo:"/home",pathMatch:'full'},
  {path:'**', component:RegisterComponent},
  
  {path:'settings',component:SettingsComponent,
    children:[
			  {path:'profile', component:SettingsProfileComponent},
			  {path:'contact', component:SettingsProfileComponent},
			  {path:'**', component:SettingsProfileComponent},
      ]
  }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
