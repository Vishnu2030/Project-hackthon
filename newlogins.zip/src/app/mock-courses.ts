import { Course } from './course';

export const  COURSES: Course[] = [
    { id:1, name:"C++"},
    { id:2, name:"Angular"},
    { id:3, name:"python"},
    { id:4, name:"SQL"},
    { id:5, name:"PHP"},
    { id:6, name:"Java"},
    { id:7, name:"CyberSecurity"},
    
];