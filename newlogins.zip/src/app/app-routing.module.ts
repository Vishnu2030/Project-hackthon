import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { TestingComponent } from './testing/testing.component';
import { ProfilesComponent } from './profiles/profiles.component';
import { TimerComponent } from './timer/timer.component';
import { InstructionsComponent } from './instructions/instructions.component';
import { AdminPanelComponent } from './admin-panel/admin-panel.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { ReportComponent } from './report/report.component';
import { NewExamComponent } from './new-exam/new-exam.component';
import { QuestionsComponent } from './questions/questions.component';

import { AdminComponent } from './admin/admin.component';
import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { SettingsProfileComponent } from './settings-profile/settings-profile.component';
import { SettingsComponent } from './settings/settings.component';



const routes: Routes = [
  {path:'home',component:HomeComponent,
    children:[
        {path:'report',component:ReportComponent},
        {path:'newexam', component:NewExamComponent,
           children:[
            {path:'questions',component:QuestionsComponent},
          ]
      },
    ]
  },
  {path:'navbar',component:NavBarComponent,
    children:[
      {path:'home',component:HomeComponent},
      {path:'about',component:AboutUsComponent},
      {path:'newexam', component:NewExamComponent},
      {path:'admin', component:AdminComponent},
      {path:'login',component:LoginComponent},
      {path:'register',component:RegisterComponent},
    
     
    ]
  },
 
  {path:'report',component:ReportComponent},
  {path:'login',component:LoginComponent},
  {path:'forgot-password',component:ForgotPasswordComponent},
  {path:'newexam', component:NewExamComponent},
  {path:'about',component:AboutUsComponent},
  {path:'404', component:PageNotFoundComponent},
  {path:'questions',component:QuestionsComponent},
  {path:'register',component:RegisterComponent},
  {path:'admin', component:AdminComponent},
  {path:'profiles',component:ProfilesComponent},
  {path:'timer',component:TimerComponent},
  {path:'instructions',component:InstructionsComponent},
  {path:'contactus',component:ContactUsComponent},
  {path:'signin',component:LoginComponent},
  {path:'', redirectTo:"/home",pathMatch:'full'},
  {path:'**', component:PageNotFoundComponent},
  {path:'admin-panel',component:AdminPanelComponent},
  {path:'admin-panel/admin-dashboard/profiles',component:AdminPanelComponent},
  {path:'admin-panel/admin-dashboard',component:AdminPanelComponent},
  {path:'testing',component:TestingComponent},
  {path:'admin-panel',component:AdminPanelComponent,
    children:[
      // {path:'', redirectTo:"/admin-panel",pathMatch:'full'},
      {path:'profiles',component:ProfilesComponent},
      {path:'', component:AdminDashboardComponent},
      {path:'**', component:PageNotFoundComponent},
    ]},
  {path:'user',component:UserDashboardComponent},
  {path:'admin-dashboard',component:AdminDashboardComponent},
  {path:'settings',component:SettingsComponent,
    children:[
			  {path:'profile', component:SettingsProfileComponent},
			  {path:'contact', component:SettingsProfileComponent},
			  {path:'**', component:SettingsProfileComponent},
      ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
