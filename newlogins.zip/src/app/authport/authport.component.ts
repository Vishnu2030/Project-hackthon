import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-authport',
  templateUrl: './authport.component.html',
  styleUrls: ['./authport.component.css']
})
export class AuthportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
