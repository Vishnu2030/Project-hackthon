import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthportComponent } from './authport.component';

describe('AuthportComponent', () => {
  let component: AuthportComponent;
  let fixture: ComponentFixture<AuthportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AuthportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
