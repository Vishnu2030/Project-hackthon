
export class ExamUser{
    public userId!: number;

	public city!:string;

	public dob!:Date ;

	public email!:string;

	public mobile!:number;

	public password!:string;

	public qual!:string;

	public  resetPasswordToken!:string
    
    public  state!:string;

	public  username!:string;;

	public yoc!:number;
}