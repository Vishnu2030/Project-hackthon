package com.lti.dto;

public class ApplicationDto{
	
	int applicationId;
	String emailid;
	
	
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailId(String emailid) {
		this.emailid = emailid;
	}
	
	

}
