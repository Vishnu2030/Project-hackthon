package com.lti.service;

public interface AdminService {

	public String adminLogin(String Id, String password);
}
