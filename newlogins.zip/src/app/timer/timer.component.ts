import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {
  siteKey :string ;
  constructor() {
    this.siteKey = "6Ldy2vAaAAAAAF752Eb8YptSZ_MGgNXB7tTcaIoo" ;
   }
  handleEvent(event: { action: string; }){
    if(event.action === 'notify'){
      alert('Its Working fine !');
    }
  }

  ngOnInit() {
   
  }
 

}
