import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor() { }
  
  loginStatus!: boolean;
  loginstr!: any;
  ngOnInit(): void {
    this.loginstr=sessionStorage.getItem("loginInfo");
    let loginStatus:boolean=JSON.parse(this.loginstr);
    alert("login status : "+loginStatus);
  }

}
