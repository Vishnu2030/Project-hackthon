export class ExamInfo{

    public examId!: number;
    public levelId!: number;
    public qsNo!: number;
    
}